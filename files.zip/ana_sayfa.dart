import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/gunluk_vakitler.dart';
import '../theme/abyad_colors.dart';
import '../theme/abyad_text.dart';
import '../theme/abyad_tokens.dart';
import '../widgets/abyad_icon.dart';
import '../widgets/abyad_kart.dart';
import '../widgets/sekiz_kose_yildiz.dart';

/// Tasarım: Main.dc.html (Ana Sayfa)
class AnaSayfa extends StatefulWidget {
  const AnaSayfa({super.key, required this.sekmeyeGit, this.vakitler = GunlukVakitler.ornek});

  /// Alt menüde başka bir sekmeye geçmek için (1: Vakitler, 2: Kur'an, 3: Dualar, 4: Günler)
  final ValueChanged<int> sekmeyeGit;
  final GunlukVakitler vakitler;

  @override
  State<AnaSayfa> createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  late Timer _zamanlayici;
  DateTime _simdi = DateTime.now();

  @override
  void initState() {
    super.initState();
    // Geri sayım dakika bazında; 15 sn'de bir yenilemek yeterli ve pil dostu.
    _zamanlayici = Timer.periodic(const Duration(seconds: 15), (_) {
      setState(() => _simdi = DateTime.now());
    });
  }

  @override
  void dispose() {
    _zamanlayici.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light, // koyu başlık üstünde açık durum çubuğu
      child: ListView(
        padding: const EdgeInsets.only(bottom: AbyadSpace.xxl),
        children: [
          _BaslikAlani(vakitler: widget.vakitler, simdi: _simdi),
          const SizedBox(height: AbyadSpace.bolumArasi),
          _HizliErisim(sekmeyeGit: widget.sekmeyeGit),
          const SizedBox(height: AbyadSpace.bolumArasi),
          _kenarli(_DevamKarti(onTap: () => widget.sekmeyeGit(2))),
          const SizedBox(height: AbyadSpace.bolumArasi),
          _kenarli(const _GununAyeti()),
          const SizedBox(height: AbyadSpace.bolumArasi),
          _kenarli(_YaklasanGun(onTap: () => widget.sekmeyeGit(4))),
        ],
      ),
    );
  }

  Widget _kenarli(Widget w) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: AbyadSpace.ekranKenar),
        child: w,
      );
}

// ---------------------------------------------------------------------------
// Koyu başlık: konum, tarih, sıradaki vakit, 6 vakit
// ---------------------------------------------------------------------------
class _BaslikAlani extends StatelessWidget {
  const _BaslikAlani({required this.vakitler, required this.simdi});

  final GunlukVakitler vakitler;
  final DateTime simdi;

  @override
  Widget build(BuildContext context) {
    final ustBosluk = MediaQuery.paddingOf(context).top;
    final simdiki = vakitler.simdikiIndex(simdi);
    final sonraki = vakitler.sonrakiIndex(simdi);
    final sonrakiVakit = vakitler.vakitler[sonraki];
    final kalan = kalanMetni(vakitler.sonrakineKalan(simdi));

    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: const BoxDecoration(
        color: AbyadColors.zumrut,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(AbyadRadius.baslikAlt)),
      ),
      child: Stack(
        children: [
          const Positioned(
            right: -80,
            top: -60,
            child: Opacity(
              opacity: 0.35,
              child: SekizKoseYildiz(boyut: 280, renk: AbyadColors.pirinc, cizgiKalinligi: 1.4),
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(20, ustBosluk + 16, 20, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            const AbyadIcon('pin', renk: AbyadColors.koyuUstuIkincil, boyut: 16),
                            const SizedBox(width: 6),
                            Text(vakitler.sehir,
                                style: abyadStil(AbyadFonts.metin, 13, 500,
                                    color: AbyadColors.koyuUstuIkincil)),
                          ]),
                          const SizedBox(height: 4),
                          Text('${vakitler.hicriTarih} · ${vakitler.miladiTarih}',
                              style: abyadStil(AbyadFonts.metin, 13, 500, color: AbyadColors.pirinc)),
                        ],
                      ),
                    ),
                    _YuvarlakIkonDugme(
                      ikon: 'bell',
                      etiket: 'Bildirimler',
                      onTap: () {},
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Semantics(
                  container: true,
                  label: 'Sıradaki vakit ${sonrakiVakit.ad}, saat ${sonrakiVakit.metin}, $kalan',
                  excludeSemantics: true,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Sıradaki vakit · ${sonrakiVakit.ad}',
                          style: abyadStil(AbyadFonts.metin, 14, 500,
                              color: AbyadColors.koyuUstuIkincil)),
                      Text(sonrakiVakit.metin, style: AbyadText.saatDev),
                      Text(kalan,
                          style: abyadStil(AbyadFonts.metin, 14, 500, color: AbyadColors.yuzey)),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    for (var i = 0; i < vakitler.vakitler.length; i++) ...[
                      if (i > 0) const SizedBox(width: 6),
                      Expanded(
                        child: _VakitCipi(
                          vakit: vakitler.vakitler[i],
                          sirada: i == sonraki,
                          simdiki: i == simdiki,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _VakitCipi extends StatelessWidget {
  const _VakitCipi({required this.vakit, required this.sirada, required this.simdiki});

  final Vakit vakit;
  final bool sirada;
  final bool simdiki;

  @override
  Widget build(BuildContext context) {
    final zemin = sirada
        ? AbyadColors.pirinc
        : (simdiki ? AbyadColors.koyuUstuSecili : AbyadColors.koyuUstuKart);
    final adRengi = sirada
        ? AbyadColors.zumrut
        : (simdiki ? AbyadColors.yuzey : AbyadColors.koyuUstuIkincil);
    final saatRengi = sirada ? AbyadColors.zumrut : AbyadColors.yuzey;
    final durum = sirada ? ', sıradaki vakit' : (simdiki ? ', şu anki vakit' : '');

    return Semantics(
      label: '${vakit.ad} ${vakit.metin}$durum',
      excludeSemantics: true,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(color: zemin, borderRadius: BorderRadius.circular(AbyadRadius.cip)),
        child: Column(
          children: [
            Text(vakit.ad,
                maxLines: 1,
                overflow: TextOverflow.fade,
                softWrap: false,
                style: abyadStil(AbyadFonts.metin, 11, sirada ? 600 : 500, color: adRengi)),
            const SizedBox(height: 4),
            Text(vakit.metin, style: abyadStil(AbyadFonts.metin, 14, 700, color: saatRengi)),
          ],
        ),
      ),
    );
  }
}

class _YuvarlakIkonDugme extends StatelessWidget {
  const _YuvarlakIkonDugme({required this.ikon, required this.etiket, required this.onTap});

  final String ikon;
  final String etiket;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      shape: const CircleBorder(side: BorderSide(color: AbyadColors.koyuUstuKenar)),
      clipBehavior: Clip.antiAlias,
      child: IconButton(
        tooltip: etiket, // ekran okuyucu bu etiketi okur
        onPressed: onTap,
        constraints: const BoxConstraints.tightFor(width: 48, height: 48),
        icon: AbyadIcon(ikon, renk: AbyadColors.yuzey, boyut: 20),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Hızlı erişim: Kıble, Kur'an, Zikirmatik, Dualar
// ---------------------------------------------------------------------------
class _HizliErisim extends StatelessWidget {
  const _HizliErisim({required this.sekmeyeGit});
  final ValueChanged<int> sekmeyeGit;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AbyadSpace.ekranKenar),
      child: Row(
        children: [
          Expanded(child: _HizliDugme(ikon: 'compass', etiket: 'Kıble', onTap: () => sekmeyeGit(1))),
          const SizedBox(width: 10),
          Expanded(child: _HizliDugme(ikon: 'book', etiket: "Kur'an", onTap: () => sekmeyeGit(2))),
          const SizedBox(width: 10),
          // TODO: Zikirmatik ekranı kodlanınca Navigator.push ile açılacak
          Expanded(child: _HizliDugme(ikon: 'counter', etiket: 'Zikirmatik', onTap: () => sekmeyeGit(3))),
          const SizedBox(width: 10),
          Expanded(child: _HizliDugme(ikon: 'moon', etiket: 'Dualar', onTap: () => sekmeyeGit(3))),
        ],
      ),
    );
  }
}

class _HizliDugme extends StatelessWidget {
  const _HizliDugme({required this.ikon, required this.etiket, required this.onTap});

  final String ikon;
  final String etiket;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: etiket,
      excludeSemantics: true,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AbyadRadius.ikonKutu),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  color: AbyadColors.yuzey,
                  borderRadius: BorderRadius.circular(AbyadRadius.ikonKutu),
                  border: Border.all(color: AbyadColors.kenarlik),
                ),
                alignment: Alignment.center,
                child: AbyadIcon(ikon, renk: AbyadColors.zumrut),
              ),
              const SizedBox(height: 8),
              Text(etiket,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: abyadStil(AbyadFonts.metin, 12, 600)),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Kaldığın yerden devam et
// ---------------------------------------------------------------------------
class _DevamKarti extends StatelessWidget {
  const _DevamKarti({required this.onTap});
  final VoidCallback onTap;

  // ÖRNEK VERİ — okuma ilerlemesi cihazda saklanınca buradan okunacak
  static const _sayfa = 42;
  static const _toplamSayfa = 604;

  @override
  Widget build(BuildContext context) {
    final oran = _sayfa / _toplamSayfa;
    return AbyadKart(
      onTap: onTap,
      semanticLabel: 'Kaldığın yerden devam et: Bakara, 255. ayet. Hatim yüzde ${(oran * 100).round()}',
      child: ExcludeSemantics(
        child: Row(
          children: [
            _ikonKutusu('bookmark', AbyadColors.yesilZemin, AbyadColors.zumrut),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Kaldığın yerden devam et', style: AbyadText.etiket),
                  const SizedBox(height: 4),
                  Text('Bakara · 255. ayet', style: AbyadText.kartBasligi),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: LinearProgressIndicator(
                      value: oran,
                      minHeight: 6,
                      backgroundColor: AbyadColors.yesilZemin,
                      color: AbyadColors.zumrut,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text('Hatim %${(oran * 100).round()} · Sayfa $_sayfa / $_toplamSayfa',
                      style: AbyadText.etiket),
                ],
              ),
            ),
            const SizedBox(width: 8),
            const AbyadIcon('chevron_right', renk: AbyadColors.metinIkincil, boyut: 20),
          ],
        ),
      ),
    );
  }
}

Widget _ikonKutusu(String ikon, Color zemin, Color renk) => Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(color: zemin, borderRadius: BorderRadius.circular(AbyadRadius.dugme)),
      alignment: Alignment.center,
      child: AbyadIcon(ikon, renk: renk, boyut: 22),
    );

// ---------------------------------------------------------------------------
// Günün ayeti
// ---------------------------------------------------------------------------
class _GununAyeti extends StatelessWidget {
  const _GununAyeti();

  @override
  Widget build(BuildContext context) {
    return AbyadKart(
      padding: const EdgeInsets.all(AbyadSpace.xl),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(children: [
            const SekizKoseYildiz(boyut: 16, renk: AbyadColors.pirincYazi, cizgiKalinligi: 1.1, halkalar: false),
            const SizedBox(width: 8),
            Text('Günün Ayeti',
                style: abyadStil(AbyadFonts.metin, 13, 700, color: AbyadColors.pirincYazi)),
          ]),
          const SizedBox(height: 12),
          Text(
            'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ',
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.right,
            style: AbyadText.arapcaAyet,
          ),
          const SizedBox(height: 12),
          Text("Haberiniz olsun, kalpler ancak Allah'ı anmakla huzura kavuşur.",
              style: AbyadText.govde),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: Text("Ra'd Suresi, 28", style: AbyadText.kucuk)),
              IconButton(
                tooltip: 'Ayeti paylaş',
                onPressed: () {}, // TODO: share_plus ile paylaş
                icon: const AbyadIcon('share', renk: AbyadColors.zumrut, boyut: 18),
                style: IconButton.styleFrom(
                  side: const BorderSide(color: AbyadColors.kenarlik),
                  minimumSize: const Size(48, 48),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Yaklaşan mübarek gün
// ---------------------------------------------------------------------------
class _YaklasanGun extends StatelessWidget {
  const _YaklasanGun({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    // ÖRNEK VERİ — Diyanet'in dinî günler listesinden okunacak
    return AbyadKart(
      onTap: onTap,
      semanticLabel: 'Yaklaşan mübarek gün: Regaip Kandili, 10 Aralık 2026 Perşembe, 69 gün kaldı',
      child: ExcludeSemantics(
        child: Row(
          children: [
            _ikonKutusu('calendar', AbyadColors.pirincZemin, AbyadColors.pirincYazi),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Yaklaşan mübarek gün', style: AbyadText.etiket),
                  const SizedBox(height: 3),
                  Text('Regaip Kandili', style: AbyadText.kartBasligi),
                  const SizedBox(height: 3),
                  Text('10 Aralık 2026 Perşembe', style: AbyadText.kucuk),
                ],
              ),
            ),
            Column(children: [
              Text('69', style: AbyadText.sayiBuyuk),
              Text('gün', style: AbyadText.etiket),
            ]),
          ],
        ),
      ),
    );
  }
}
