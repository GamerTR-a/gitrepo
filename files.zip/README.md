# Abyad – Flutter Başlangıç Paketi

Bu paket, kanvastaki tasarımların Flutter projesine aktarılmış ilk hâlidir:
tasarım dili (renk, yazı tipi, ölçü), ikonlar, süsleme, alt menülü uygulama
iskeleti ve tamamen kodlanmış **Ana Sayfa** ekranı.

> Not: Bu kod, hazırlandığı ortamda Flutter SDK bulunmadığı için derlenip
> çalıştırılamadı. `flutter analyze` ilk çalıştırmada küçük bir uyarı
> verirse kolayca düzeltilebilir düzeydedir.

## Kurulum

1. Yeni proje oluşturun:
   `flutter create --org com.ornek abyad`
   (`com.ornek` yerine kendi alan adınızı ters yazın, ör. `com.abyadapp`.
   Bu kimlik mağazada sonradan değiştirilemez.)
2. Bu paketteki `lib/`, `assets/` ve `fonts/` klasörlerini projenin köküne
   kopyalayın (`lib/main.dart` dosyasının üzerine yazılması normaldir).
3. `pubspec.yaml` dosyasını bu paketteki ile değiştirin
   (ya da `flutter_svg` bağımlılığını, `assets` ve `fonts` bölümlerini ekleyin).
4. `flutter pub get` ve `flutter run`.

## Klasör yapısı

```
lib/
  main.dart                  Uygulama + alt menülü iskelet (AbyadKabuk)
  theme/
    abyad_colors.dart        Bütün renkler
    abyad_text.dart          Yazı tipleri ve yazı stilleri
    abyad_tokens.dart        Boşluk, köşe, dokunma alanı ölçüleri
    abyad_theme.dart         Material ThemeData
  widgets/
    abyad_alt_menu.dart      5 sekmeli alt menü
    abyad_kart.dart          Standart beyaz kart
    abyad_icon.dart          SVG ikonları renklendirerek gösterir
    sekiz_kose_yildiz.dart   Rub'ul-hizb süslemesi (CustomPainter)
  models/
    gunluk_vakitler.dart     Vakit modeli + sıradaki vakit / geri sayım hesabı
  screens/
    ana_sayfa.dart           Ana Sayfa (Main.dc.html) – tamamlandı
    yer_tutucu_ekran.dart    Henüz kodlanmamış sekmeler için geçici ekran
assets/icons/                21 çizgi ikon (24x24 SVG)
assets/ornament/yildiz8.svg  Süsleme (ikon / açılış ekranı için)
fonts/                       Manrope, Fraunces, Amiri + OFL lisansları
```

## Tasarım dosyası → Flutter karşılığı

| Tasarım              | Flutter                              | Durum      |
|----------------------|--------------------------------------|------------|
| Main.dc.html         | screens/ana_sayfa.dart               | Hazır      |
| Vakitler.dc.html     | screens/vakitler.dart                | Sırada     |
| Kuran.dc.html        | screens/kuran_liste.dart             | Sırada     |
| KuranOku.dc.html     | screens/kuran_oku.dart               | Sırada     |
| Dualar.dc.html       | screens/dualar.dart                  | Sırada     |
| Zikirmatik.dc.html   | screens/zikirmatik.dart              | Sırada     |
| Gunler.dc.html       | screens/onemli_gunler.dart           | Sırada     |
| Ayarlar.dc.html      | screens/ayarlar.dart                 | Sırada     |
| Widget.dc.html       | Android/iOS yerel widget (home_widget)| 1. sürüm sonu |

Kanvastaki ekranları PDF/görsel olarak dışa aktarıp `docs/tasarim/` klasörüne
koymanız, kodlarken referans olarak çok işe yarar.

## Kurallar (tasarımı korumak için)

- Ekranlarda hex renk yazmayın; `AbyadColors` kullanın.
- Yazı stillerini `AbyadText` veya `abyadStil(...)` ile verin. Değişken yazı
  tiplerinde kalınlığın doğru görünmesi için bu yardımcı gereklidir.
- Her dokunulabilir öğe en az 48x48 olmalı; ikon düğmelerine mutlaka
  `tooltip` veya `Semantics(label:)` verin (ekran okuyucu için).
- Arapça metinlerde `textDirection: TextDirection.rtl` ve `AbyadFonts.arapca`.
- Sabit yükseklik vermeyin; telefonun yazı boyutu büyütüldüğünde
  taşma olmaması için içerik kendi yüksekliğini alsın.

## Sıradaki adımlar

1. **İnternetsiz vakit hesaplama:** `GunlukVakitler.ornek` yerine, cihazda
   hesaplama yapan ve Diyanet/Türkiye yöntemini destekleyen bir kütüphane
   (ör. pub.dev'deki `adhan` paketi) bağlanacak. Ekranlar sadece
   `GunlukVakitler` sınıfını tanıdığı için arayüz kodu değişmeyecek.
2. **Ezan bildirimi:** `flutter_local_notifications` ile, Android'de alarm
   ses kanalı (`AudioAttributesUsage.alarm`) ve tam zamanlı alarm izni;
   pil optimizasyonu uyarısı (Ayarlar tasarımındaki kart).
3. Vakitler ve Ayarlar ekranları.

## Lisans notları

- Yazı tipleri: SIL Open Font License 1.1 (fonts/OFL-*.txt). Uygulamaya
  gömülebilir ve ücretsiz dağıtılabilir; lisans dosyalarını uygulamayla
  birlikte tutun (ör. Ayarlar > Lisanslar).
- Kur'an Arapça metni için Tanzil projesi kaynak gösterilerek kullanılabilir;
  Türkçe meal ve tilavet kayıtları için ilgili kurumdan izin alınmalıdır.
